# Contributing
- Please understand that dotfiles are personal
- Fixes are fine
- If you make new stuff, I'll probably nitpick as I want quality
