---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: ''
assignees: ''

---

<!-- NOTE: Please write in **English**. -->

**What would you like to be added?**
<!-- Can be a suggestion for an existing feature. You can suggest a widget, minor user interaction changes.. whatever -->

**How will it help**
<!-- It's helpful to include examples (like in your use case) -->

**Extra info**
<!-- If ya want a new widget, a pic of the inspiration (if available) would be awesome -->
