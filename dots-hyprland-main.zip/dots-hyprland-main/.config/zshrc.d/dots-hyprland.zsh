# Use the generated color scheme

if test -f ~/.cache/ags/user/generated/terminal/sequences.txt; then
    cat ~/.cache/ags/user/generated/terminal/sequences.txt
fi
